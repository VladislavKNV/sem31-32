package karbanovich.fit.bstu.newsnew;

public abstract class ConnectionState {

    public abstract void loadData();
}
