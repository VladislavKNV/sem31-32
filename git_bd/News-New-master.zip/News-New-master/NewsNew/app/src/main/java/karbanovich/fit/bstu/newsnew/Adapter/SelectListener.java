package karbanovich.fit.bstu.newsnew.Adapter;

import karbanovich.fit.bstu.newsnew.Model.NewsHeadlines;

public interface SelectListener {
    void onNewsClicked(NewsHeadlines headline);
}
