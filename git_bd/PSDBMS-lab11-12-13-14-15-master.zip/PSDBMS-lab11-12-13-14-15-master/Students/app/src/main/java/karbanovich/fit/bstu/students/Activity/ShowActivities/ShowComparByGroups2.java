package karbanovich.fit.bstu.students.Activity.ShowActivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import karbanovich.fit.bstu.students.R;

public class ShowComparByGroups2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_compar_by_groups2);
    }
}